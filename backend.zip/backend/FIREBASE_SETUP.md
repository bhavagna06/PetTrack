# Firebase Setup Guide for PetTrack Backend

This guide will help you set up Firebase for image storage in the PetTrack backend.

## Prerequisites

- A Google account
- Node.js project with the backend already set up

## Step 1: Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project" or "Add project"
3. Enter a project name (e.g., "pettrack-app")
4. Choose whether to enable Google Analytics (optional)
5. Click "Create project"

## Step 2: Set Up Firebase Storage

1. In your Firebase project console, go to "Storage" in the left sidebar
2. Click "Get started"
3. Choose a location for your storage bucket (select the closest to your users)
4. Start in test mode (you can change security rules later)
5. Click "Done"

## Step 3: Create a Service Account

1. In your Firebase project console, go to "Project settings" (gear icon)
2. Go to the "Service accounts" tab
3. Click "Generate new private key"
4. Download the JSON file (this contains your service account credentials)
5. **Keep this file secure and never commit it to version control**

## Step 4: Configure Environment Variables

1. Open the downloaded service account JSON file
2. Copy the values to your `config.env` file:

```env
# Firebase Configuration
FIREBASE_PROJECT_ID=your-project-id-from-json
FIREBASE_PRIVATE_KEY_ID=your-private-key-id-from-json
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYOUR_PRIVATE_KEY_FROM_JSON\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@your-project.iam.gserviceaccount.com
FIREBASE_CLIENT_ID=your-client-id-from-json
FIREBASE_AUTH_URI=https://accounts.google.com/o/oauth2/auth
FIREBASE_TOKEN_URI=https://oauth2.googleapis.com/token
FIREBASE_AUTH_PROVIDER_X509_CERT_URL=https://www.googleapis.com/oauth2/v1/certs
FIREBASE_CLIENT_X509_CERT_URL=https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-xxxxx%40your-project.iam.gserviceaccount.com

# File Upload Configuration
MAX_FILE_SIZE=5242880
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
```

**Important Notes:**
- Replace `your-project-id` with your actual Firebase project ID
- The `FIREBASE_PRIVATE_KEY` should be the entire private key including the `-----BEGIN PRIVATE KEY-----` and `-----END PRIVATE KEY-----` parts
- The `FIREBASE_STORAGE_BUCKET` is usually your project ID followed by `.appspot.com`

## Step 5: Install Dependencies

```bash
cd backend
npm install
```

## Step 6: Test Firebase Connection

1. Start your server:
```bash
npm run dev
```

2. You should see these messages in the console:
```
✅ Firebase Admin SDK initialized successfully
✅ Connected to MongoDB successfully
🚀 Server is running on port 3000
```

## Step 7: Test Image Upload

You can test the image upload functionality using the API endpoints:

### Upload Pet Profile Image
```bash
curl -X POST http://localhost:3000/api/pets \
  -F "profileImage=@/path/to/your/image.jpg" \
  -F "petName=Buddy" \
  -F "petType=Dog" \
  -F "breed=Golden Retriever" \
  -F "color=Golden" \
  -F "homeLocation=123 Main St, New York, NY 10001" \
  -F "ownerId=YOUR_USER_ID"
```

### Upload User Profile Image
```bash
curl -X POST http://localhost:3000/api/users/register \
  -F "profileImage=@/path/to/your/image.jpg" \
  -F "name=John Doe" \
  -F "email=john@example.com" \
  -F "phone=1234567890" \
  -F "password=password123"
```

## Step 8: Configure Firebase Storage Rules (Optional)

For production, you should configure Firebase Storage security rules:

1. Go to Firebase Console > Storage > Rules
2. Update the rules to be more restrictive:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Allow read access to all files
    match /{allPaths=**} {
      allow read: if true;
    }
    
    // Allow write access only to authenticated users (when you add auth)
    match /{allPaths=**} {
      allow write: if request.auth != null;
    }
  }
}
```

## Troubleshooting

### Common Issues

1. **"Firebase Admin SDK initialization error"**
   - Check that all environment variables are set correctly
   - Verify the private key format (should include newlines)
   - Ensure the service account has the necessary permissions

2. **"Permission denied" errors**
   - Make sure your Firebase Storage bucket is in test mode
   - Check that the service account has Storage Admin role

3. **"File not found" errors**
   - Verify the file path in your upload request
   - Check that the file size is within the limit (5MB default)

4. **"Invalid private key" errors**
   - Ensure the private key is properly formatted with newlines
   - Check that the private key is not corrupted

### Security Best Practices

1. **Never commit service account keys to version control**
2. **Use environment variables for all sensitive data**
3. **Set up proper Firebase Storage security rules**
4. **Implement authentication before allowing uploads**
5. **Validate file types and sizes on both client and server**
6. **Use HTTPS in production**

## File Structure

The Firebase integration creates this structure in your storage:

```
your-project-id.appspot.com/
├── pets/
│   ├── 1234567890-123456789-pet1.jpg
│   ├── 1234567891-123456790-pet2.jpg
│   └── ...
└── users/
    ├── 1234567892-123456791-user1.jpg
    ├── 1234567893-123456792-user2.jpg
    └── ...
```

## Next Steps

1. **Add Authentication**: Implement JWT authentication for secure uploads
2. **Add Image Processing**: Resize and compress images before upload
3. **Add CDN**: Use Firebase Hosting or a CDN for faster image delivery
4. **Add Backup**: Implement backup strategies for your images
5. **Monitor Usage**: Set up Firebase Analytics and monitoring

---

**Firebase Setup Complete!** 🚀

Your PetTrack backend is now configured to use Firebase for image storage while keeping MongoDB for all other data. 