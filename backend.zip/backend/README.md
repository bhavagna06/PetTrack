# PetTrack Backend

A Node.js backend API for the PetTrack application, built with Express.js, MongoDB, and Firebase Storage for image management.

## Features

- **User Management**: Registration, login, profile management
- **Pet Profile Management**: Create, read, update, delete pet profiles
- **Image Storage**: Firebase Storage integration for profile images and pet photos
- **Data Validation**: Input validation using express-validator
- **Database Integration**: MongoDB with Mongoose ODM for data storage
- **RESTful API**: Clean and consistent API endpoints
- **Error Handling**: Comprehensive error handling and logging
- **Testing**: Automated API testing with sample data
- **Documentation**: Complete API documentation and setup guide

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas)
- Firebase project with Storage enabled
- npm or yarn package manager

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd pettrack/backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp config.env.example config.env
   # Edit config.env with your configuration
   ```

4. **Set up Firebase**
   - Follow the [Firebase Setup Guide](./FIREBASE_SETUP.md)
   - Configure Firebase Storage and service account

5. **Start MongoDB**
   ```bash
   # Local MongoDB
   mongod
   
   # Or use MongoDB Atlas (update MONGODB_URI in config.env)
   ```

6. **Run the application**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## Configuration

Create a `config.env` file in the backend directory:

```env
# Database Configuration
MONGODB_URI=mongodb://localhost:27017/pettrack
MONGODB_URI_PROD=mongodb+srv://your_username:your_password@cluster.mongodb.net/pettrack

# Server Configuration
PORT=3000
NODE_ENV=development

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRE=24h

# Firebase Configuration
FIREBASE_PROJECT_ID=your-firebase-project-id
FIREBASE_PRIVATE_KEY_ID=your-private-key-id
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@your-project.iam.gserviceaccount.com
FIREBASE_CLIENT_ID=your-client-id
FIREBASE_AUTH_URI=https://accounts.google.com/o/oauth2/auth
FIREBASE_TOKEN_URI=https://oauth2.googleapis.com/token
FIREBASE_AUTH_PROVIDER_X509_CERT_URL=https://www.googleapis.com/oauth2/v1/certs
FIREBASE_CLIENT_X509_CERT_URL=https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-xxxxx%40your-project.iam.gserviceaccount.com

# File Upload Configuration
MAX_FILE_SIZE=5242880
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
```

## API Endpoints

### Users

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/users/register` | Register a new user |
| POST | `/api/users/login` | Login user |
| GET | `/api/users` | Get all users |
| GET | `/api/users/:id` | Get user by ID |
| PUT | `/api/users/:id` | Update user profile |
| DELETE | `/api/users/:id` | Delete user (soft delete) |
| POST | `/api/users/:id/verify` | Verify user account |
| POST | `/api/users/:id/update-notifications` | Update notification preferences |

### Pets

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pets` | Create a new pet profile |
| GET | `/api/pets` | Get all pets |
| GET | `/api/pets/:id` | Get pet by ID |
| PUT | `/api/pets/:id` | Update pet profile |
| DELETE | `/api/pets/:id` | Delete pet (soft delete) |
| POST | `/api/pets/:id/upload-photos` | Upload additional photos |
| POST | `/api/pets/:id/mark-lost` | Mark pet as lost |
| POST | `/api/pets/:id/mark-found` | Mark pet as found |
| GET | `/api/pets/owner/:ownerId` | Get pets by owner |

## Data Models

### User Schema

```javascript
{
  name: String (required),
  email: String (required, unique),
  phone: String (required, unique),
  password: String (required, hashed),
  profileImage: String (Firebase URL),
  address: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  isActive: Boolean (default: true),
  isVerified: Boolean (default: false),
  notifications: {
    email: Boolean (default: true),
    push: Boolean (default: true),
    sms: Boolean (default: true)
  },
  createdAt: Date,
  updatedAt: Date,
  lastLogin: Date
}
```

### Pet Schema

```javascript
{
  petName: String (required),
  petType: String (required, enum),
  breed: String (required),
  color: String (required, enum),
  homeLocation: String (required),
  profileImage: String (Firebase URL),
  additionalPhotos: [String] (Firebase URLs),
  ownerId: ObjectId (required, ref: User),
  isActive: Boolean (default: true),
  isLost: Boolean (default: false),
  isFound: Boolean (default: false),
  createdAt: Date,
  updatedAt: Date
}
```

## Example API Usage

### Register a User with Profile Image

```bash
curl -X POST http://localhost:3000/api/users/register \
  -F "profileImage=@/path/to/profile.jpg" \
  -F "name=John Doe" \
  -F "email=john@example.com" \
  -F "phone=1234567890" \
  -F "password=password123"
```

### Create a Pet Profile with Image

```bash
curl -X POST http://localhost:3000/api/pets \
  -F "profileImage=@/path/to/pet.jpg" \
  -F "petName=Buddy" \
  -F "petType=Dog" \
  -F "breed=Golden Retriever" \
  -F "color=Golden" \
  -F "homeLocation=123 Main St, New York, NY 10001" \
  -F "ownerId=USER_ID_HERE"
```

### Upload Additional Pet Photos

```bash
curl -X POST http://localhost:3000/api/pets/PET_ID/upload-photos \
  -F "photos=@/path/to/photo1.jpg" \
  -F "photos=@/path/to/photo2.jpg"
```

### Get All Pets

```bash
curl http://localhost:3000/api/pets
```

## Development

### Project Structure

```
backend/
├── config/
│   └── firebase.js
├── models/
│   ├── User.js
│   └── Pet.js
├── routes/
│   ├── userRoutes.js
│   └── petRoutes.js
├── views/
│   └── index.ejs
├── server.js
├── package.json
├── config.env
├── sample-data.js
├── test-api.js
├── README.md
├── SETUP_GUIDE.md
└── FIREBASE_SETUP.md
```

### Available Scripts

- `npm start` - Start the server in production mode
- `npm run dev` - Start the server in development mode with nodemon
- `npm test` - Run API tests
- `npm run seed` - Seed the database with sample data
- `npm run seed:clear` - Clear all data from the database

### Testing

Run the automated API tests:

```bash
npm test
```

This will test all major endpoints and provide detailed results.

### Database Seeding

Populate the database with sample data:

```bash
npm run seed
```

Clear all data:

```bash
npm run seed:clear
```

## Firebase Integration

The backend uses Firebase Storage for image management:

- **Profile Images**: Stored in Firebase Storage with public URLs
- **Pet Photos**: Multiple photos per pet stored in organized folders
- **Automatic Cleanup**: Old images are deleted when profiles are updated or deleted
- **Security**: Images are validated and stored with proper access controls

For detailed Firebase setup instructions, see [FIREBASE_SETUP.md](./FIREBASE_SETUP.md).

## Deployment

### Environment Variables

Set the following environment variables for production:

- `MONGODB_URI_PROD` - Production MongoDB connection string
- `NODE_ENV` - Set to "production"
- `JWT_SECRET` - Strong secret key for JWT tokens
- All Firebase configuration variables

### Security Considerations

- Use HTTPS in production
- Implement rate limiting
- Add authentication middleware
- Validate and sanitize all inputs
- Use environment variables for sensitive data
- Configure Firebase Storage security rules
- Regular security updates

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please open an issue in the repository. 