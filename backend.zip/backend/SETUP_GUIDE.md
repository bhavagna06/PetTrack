# PetTrack Backend - Quick Setup Guide

This guide will help you quickly set up and run the PetTrack backend with Firebase integration.

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (local or MongoDB Atlas)
- Firebase project with Storage enabled
- npm or yarn

## Quick Setup

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Configure Environment

Create `config.env` file:

```env
# Database Configuration
MONGODB_URI=mongodb://localhost:27017/pettrack
MONGODB_URI_PROD=mongodb+srv://your_username:your_password@cluster.mongodb.net/pettrack

# Server Configuration
PORT=3000
NODE_ENV=development

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRE=24h

# Firebase Configuration
FIREBASE_PROJECT_ID=your-firebase-project-id
FIREBASE_PRIVATE_KEY_ID=your-private-key-id
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@your-project.iam.gserviceaccount.com
FIREBASE_CLIENT_ID=your-client-id
FIREBASE_AUTH_URI=https://accounts.google.com/o/oauth2/auth
FIREBASE_TOKEN_URI=https://oauth2.googleapis.com/token
FIREBASE_AUTH_PROVIDER_X509_CERT_URL=https://www.googleapis.com/oauth2/v1/certs
FIREBASE_CLIENT_X509_CERT_URL=https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-xxxxx%40your-project.iam.gserviceaccount.com

# File Upload Configuration
MAX_FILE_SIZE=5242880
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
```

### 3. Set Up Firebase

**Follow the detailed Firebase setup guide:**
- See [FIREBASE_SETUP.md](./FIREBASE_SETUP.md) for complete instructions
- Create a Firebase project
- Enable Firebase Storage
- Generate service account credentials
- Update the Firebase configuration in `config.env`

### 4. Start MongoDB

**Local MongoDB:**
```bash
mongod
```

**MongoDB Atlas:**
- Create a free cluster at [MongoDB Atlas](https://www.mongodb.com/atlas)
- Get your connection string and update `MONGODB_URI` in `config.env`

### 5. Start the Server

```bash
# Development mode (with auto-restart)
npm run dev

# Production mode
npm start
```

The server will start on `http://localhost:3000`

### 6. Test the API

```bash
# Run automated tests
npm test

# Seed database with sample data
npm run seed
```

### 7. Verify Installation

- **Health Check:** `http://localhost:3000/health`
- **API Dashboard:** `http://localhost:3000`
- **API Documentation:** Check the README.md file

## API Quick Test

### Create a User with Profile Image
```bash
curl -X POST http://localhost:3000/api/users/register \
  -F "profileImage=@/path/to/profile.jpg" \
  -F "name=Test User" \
  -F "email=test@example.com" \
  -F "phone=1234567890" \
  -F "password=password123"
```

### Create a Pet with Image
```bash
curl -X POST http://localhost:3000/api/pets \
  -F "profileImage=@/path/to/pet.jpg" \
  -F "petName=Buddy" \
  -F "petType=Dog" \
  -F "breed=Golden Retriever" \
  -F "color=Golden" \
  -F "homeLocation=123 Main St, New York, NY 10001" \
  -F "ownerId=USER_ID_FROM_PREVIOUS_STEP"
```

### Upload Additional Pet Photos
```bash
curl -X POST http://localhost:3000/api/pets/PET_ID/upload-photos \
  -F "photos=@/path/to/photo1.jpg" \
  -F "photos=@/path/to/photo2.jpg"
```

## Integration with Flutter

The backend is ready to integrate with your Flutter app. Key endpoints:

- **User Management:** `/api/users/register`, `/api/users/login`
- **Pet Management:** `/api/pets` (GET, POST, PUT, DELETE)
- **Image Upload:** Profile images and additional photos via Firebase
- **Pet Status:** `/api/pets/:id/mark-lost`, `/api/pets/:id/mark-found`

## Database Architecture

**MongoDB (Data Storage):**
- User profiles and authentication
- Pet profiles and details
- Relationships and metadata

**Firebase Storage (Image Storage):**
- User profile images
- Pet profile images
- Additional pet photos
- Organized folder structure

## Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Ensure MongoDB is running
   - Check connection string in `config.env`

2. **Firebase Connection Error**
   - Verify Firebase configuration in `config.env`
   - Check service account credentials
   - Ensure Firebase Storage is enabled

3. **Port Already in Use**
   - Change `PORT` in `config.env`
   - Or kill the process using port 3000

4. **Module Not Found**
   - Run `npm install` again
   - Check Node.js version (v14+)

5. **Image Upload Errors**
   - Verify file size is within limits (5MB default)
   - Check file format (images only)
   - Ensure Firebase Storage bucket is accessible

### Getting Help

- Check the main README.md for detailed documentation
- Follow the Firebase setup guide: [FIREBASE_SETUP.md](./FIREBASE_SETUP.md)
- Run `npm test` to verify API functionality
- Check server logs for error details

## Next Steps

1. **Add Authentication:** Implement JWT middleware
2. **Add Validation:** Enhance input validation
3. **Add Rate Limiting:** Protect against abuse
4. **Configure Firebase Rules:** Set up proper security rules
5. **Deploy:** Set up production environment

---

**PetTrack Backend** - Ready for your Flutter app with Firebase integration! 🚀 